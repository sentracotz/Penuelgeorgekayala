import { createFileRoute } from "@tanstack/react-router";
import { Portfolio } from "@/components/site/portfolio";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Penuel George Kayala — Engineer in Dar es Salaam" },
      {
        name: "description",
        content:
          "Penuel George Kayala builds across software and machines in Dar es Salaam. Python, C++, the web, robotics, electronics, laser work, CAD, and CAM.",
      },
    ],
  }),
  component: Portfolio,
});
