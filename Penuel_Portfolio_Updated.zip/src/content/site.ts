export const profile = {
  fullName: "Penuel George Kayala",
  name: "Penuel George",
  given: "Penuel",
  family: "George",
  place: "Dar es Salaam",
  country: "Tanzania",
  slogan: "Practical thinking. Thoughtful engineering. Work that delivers.",
  email: "penuelgeorge.tz@gmail.com",
  emailAlt: "sentra.co.tz@gmail.com",
  phoneDisplay: "+255 613 437 684",
  phoneWa: "255613437684",
  linkedin: "https://www.linkedin.com/in/penuel-george-kayala",
  instagram: "https://www.instagram.com/penuelgeorge.tz",
  portrait: "/portrait.jpg",
} as const;

export const whatsappHref = `https://wa.me/${profile.phoneWa}`;

export type Practice = {
  id: string;
  index: string;
  title: string;
  tools: string;
  lead: string;
  detail: string;
  includes: string[];
};

export const practices: Practice[] = [
  {
    id: "software",
    index: "01",
    title: "Software",
    tools: "Python · C++",
    lead: "Useful software, built around real needs.",
    detail:
      "I use Python and C++ to build tools, work through technical problems, and develop the software behind products and machines. The focus is on code that is clear, dependable, and suited to its purpose.",
    includes: ["Python", "C++"],
  },
  {
    id: "web",
    index: "02",
    title: "Web",
    tools: "HTML · CSS · Web development",
    lead: "Clear, responsive websites and interfaces.",
    detail:
      "I create websites and digital interfaces with HTML and CSS, paying attention to usability, responsive layouts, and the details that make a site work well across phones, tablets, and desktops.",
    includes: ["HTML", "CSS", "Web development"],
  },
  {
    id: "robotics",
    index: "03",
    title: "Robotics",
    tools: "Robotics · Automation",
    lead: "Automation designed to solve practical problems.",
    detail:
      "I am interested in building robotic and automated systems that make practical tasks more consistent. That means thinking carefully about movement, control, and how each part of a system works together.",
    includes: ["Robotics", "Automation"],
  },
  {
    id: "electronics",
    index: "04",
    title: "Electronics",
    tools: "Electronics",
    lead: "Electronics designed with the whole system in mind.",
    detail:
      "I work with the electronic side of projects where hardware and software need to operate as one system. Circuit design and electrical decisions are considered from the beginning, not left until the end.",
    includes: ["Electronics"],
  },
  {
    id: "laser",
    index: "05",
    title: "Laser",
    tools: "Laser work",
    lead: "Accurate laser work, from file to finished piece.",
    detail:
      "I use laser processes for cutting and marking, with care given to file preparation, material requirements, and the accuracy of the finished result.",
    includes: ["Laser work"],
  },
  {
    id: "cadcam",
    index: "06",
    title: "CAD & CAM",
    tools: "CAD · CAM",
    lead: "Designs developed with manufacturing in mind.",
    detail:
      "I use CAD and CAM to develop and prepare parts for production. A good design should not only look right on screen; it should also be practical to manufacture.",
    includes: ["CAD", "CAM"],
  },
];

export const fullBuild = {
  id: "full",
  title: "A full build",
  detail: "Software and the physical work, kept in one brief.",
};

export const method = [
  {
    index: "01",
    title: "Understand the brief",
    text: "I start by understanding the goal, who the work is for, and what the finished result needs to achieve.",
  },
  {
    index: "02",
    title: "Plan the approach",
    text: "I choose the right tools and map out a practical approach, whether the project involves software, design, electronics, or a combination.",
  },
  {
    index: "03",
    title: "Build and test",
    text: "I develop the solution in stages, test the important details, and refine the work as the project takes shape.",
  },
  {
    index: "04",
    title: "Deliver with clarity",
    text: "I aim to deliver work that is ready to use, with a clear explanation of what has been built and how it works.",
  },
] as const;

export const lines = [
  "software tools.",
  "web experiences.",
  "robotic and automated systems.",
  "electronic systems.",
  "laser-cut and marked components.",
  "CAD/CAM workflows.",
];

export function messageFor(name: string, topic: string, note: string) {
  const who = name.trim() ? `I'm ${name.trim()}. ` : "";
  const body = note.trim() ? `\n\n${note.trim()}` : "";
  return `Hello Penuel, ${who}I want to talk about ${topic}.${body}`;
}

export function mailtoHref(email: string, topic: string, body: string) {
  const subject = `Work enquiry — ${topic}`;
  return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export function whatsappMessageHref(body: string) {
  return `${whatsappHref}?text=${encodeURIComponent(body)}`;
}

export const personJsonLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: profile.fullName,
  alternateName: profile.name,
  jobTitle: "Engineer and software developer",
  email: profile.email,
  telephone: "+255613437684",
  address: {
    "@type": "PostalAddress",
    addressLocality: profile.place,
    addressCountry: "TZ",
  },
  sameAs: [profile.linkedin, profile.instagram],
  knowsAbout: [
    "Python",
    "C++",
    "HTML",
    "CSS",
    "Web development",
    "Robotics",
    "Automation",
    "Electronics",
    "Laser work",
    "Computer-aided design",
    "Computer-aided manufacturing",
  ],
};
