import { useEffect, useMemo, useState, type KeyboardEvent, type ReactNode } from "react";
import { ArrowUpRight, Check, Copy, Instagram, Linkedin, Mail, MessageCircle } from "lucide-react";
import {
  fullBuild,
  lines,
  mailtoHref,
  messageFor,
  method,
  personJsonLd,
  practices,
  profile,
  whatsappHref,
  whatsappMessageHref,
} from "@/content/site";
import { cn } from "@/lib/cn";

const topics = [
  ...practices.map((item) => ({ id: item.id, label: item.title })),
  { id: fullBuild.id, label: fullBuild.title },
];

export function Portfolio() {
  const [line, setLine] = useState(0);
  const [shown, setShown] = useState(true);
  const [practiceId, setPracticeId] = useState(practices[0].id);
  const [topicId, setTopicId] = useState(fullBuild.id);
  const [name, setName] = useState("");
  const [note, setNote] = useState("");
  const [inbox, setInbox] = useState<"personal" | "sentra">("personal");
  const [copied, setCopied] = useState("");

  const practice = practices.find((item) => item.id === practiceId) ?? practices[0];
  const topic = topics.find((item) => item.id === topicId) ?? topics[0];
  const draft = useMemo(() => messageFor(name, topic.label.toLowerCase(), note), [name, note, topic.label]);
  const email = inbox === "personal" ? profile.email : profile.emailAlt;

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const id = window.setInterval(() => {
      setShown(false);
      window.setTimeout(() => {
        setLine((current) => (current + 1) % lines.length);
        setShown(true);
      }, 180);
    }, 2600);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!copied) return;
    const id = window.setTimeout(() => setCopied(""), 1800);
    return () => window.clearTimeout(id);
  }, [copied]);

  async function copy(value: string, id: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(id);
    } catch {
      setCopied("");
    }
  }

  function briefThis(id: string) {
    setTopicId(id);
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    document.getElementById("contact")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
    window.setTimeout(() => document.getElementById("brief-note")?.focus(), 400);
  }

  function onPracticeKey(event: KeyboardEvent) {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    event.preventDefault();
    const index = practices.findIndex((item) => item.id === practiceId);
    const next =
      event.key === "ArrowDown"
        ? (index + 1) % practices.length
        : (index - 1 + practices.length) % practices.length;
    const id = practices[next].id;
    setPracticeId(id);
    document.getElementById(`practice-${id}`)?.focus();
  }

  return (
    <main id="top">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(personJsonLd) }} />

      <section className="relative overflow-hidden border-b border-line">
        <div className="grid-field pointer-events-none absolute inset-0" aria-hidden />
        <div className="hero-block relative mx-auto grid w-full max-w-6xl items-center gap-12 px-5 py-14 md:px-8 lg:grid-cols-[1.15fr_0.85fr] lg:py-20">
          <div>
            <p className="rise text-sm font-semibold tracking-widest text-accent uppercase">
              {profile.place}, {profile.country}
            </p>
            <h1 className="rise d1 mt-4 font-display text-6xl leading-none font-bold text-fg sm:text-7xl lg:text-8xl">
              {profile.given}
              <br />
              {profile.family}
            </h1>
            <p className="rise d2 mt-5 text-lg text-fg">
              I build{" "}
              <span
                className={cn(
                  "text-accent transition-opacity duration-200",
                  shown ? "opacity-100" : "opacity-0",
                )}
              >
                {lines[line]}
              </span>
            </p>
            <p className="rise d3 mt-4 max-w-xl text-base text-muted">
              I am an engineer and developer based in Dar es Salaam, Tanzania. My work and interests span software development, web technologies, robotics, electronics, laser processes, and CAD/CAM. I enjoy projects that connect digital ideas with practical, physical results.
            </p>
            <p className="rise d3 mt-3 text-sm font-medium tracking-wide text-fg uppercase">{profile.slogan}</p>
            <div className="rise d4 mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href={whatsappHref}
                className="inline-flex h-12 items-center justify-center gap-2 bg-accent px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                <MessageCircle className="size-4" aria-hidden />
                WhatsApp {profile.phoneDisplay}
              </a>
              <a
                href={`mailto:${profile.email}`}
                className="inline-flex h-12 items-center justify-center gap-2 border border-line bg-surface px-5 text-sm font-semibold text-fg transition-colors duration-200 hover:border-accent"
              >
                <Mail className="size-4" aria-hidden />
                Email
              </a>
            </div>
            <div className="rise d4 mt-6 flex flex-wrap gap-3">
              <Social href={profile.linkedin} label="LinkedIn">
                <Linkedin className="size-4" aria-hidden />
              </Social>
              <Social href={profile.instagram} label="Instagram">
                <Instagram className="size-4" aria-hidden />
              </Social>
            </div>
          </div>
          <figure className="rise d2 relative mx-auto hidden w-full lg:block">
            <span className="pointer-events-none absolute -top-3 -left-3 size-8 border-t-2 border-l-2 border-accent" aria-hidden />
            <span className="pointer-events-none absolute -right-3 -bottom-3 size-8 border-r-2 border-b-2 border-accent" aria-hidden />
            <div className="portrait-frame overflow-hidden border border-line bg-surface">
              <img
                src={profile.portrait}
                alt="Penuel George Kayala, Dar es Salaam"
                className="h-full w-full"
                width={900}
                height={1125}
              />
            </div>
            <figcaption className="mt-4 flex items-center justify-between gap-3 text-sm">
              <span className="font-medium text-fg">{profile.fullName}</span>
              <span className="text-muted">Available for selected projects</span>
            </figcaption>
          </figure>
        </div>
      </section>

      <section id="about" className="scroll-mt-20 border-b border-line">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-20 md:px-8 lg:grid-cols-[0.8fr_1.2fr]">
          <p className="text-sm font-semibold tracking-widest text-accent uppercase">About</p>
          <div>
            <figure className="relative mb-10 lg:hidden">
              <span className="pointer-events-none absolute -top-3 -left-3 size-8 border-t-2 border-l-2 border-accent" aria-hidden />
              <span className="pointer-events-none absolute -right-3 -bottom-3 size-8 border-r-2 border-b-2 border-accent" aria-hidden />
              <div className="portrait-frame overflow-hidden border border-line bg-surface">
                <img
                  src={profile.portrait}
                  alt="Penuel George Kayala, Dar es Salaam"
                  className="h-full w-full"
                  width={900}
                  height={1125}
                />
              </div>
              <figcaption className="mt-4 flex items-center justify-between gap-3 text-sm">
                <span className="font-medium text-fg">{profile.fullName}</span>
                <span className="text-muted">Available for selected projects</span>
              </figcaption>
            </figure>
            <h2 className="font-display text-4xl leading-tight font-bold text-fg sm:text-5xl">
              From software to physical systems, I turn ideas into practical solutions.
            </h2>
            <div className="mt-6 max-w-2xl space-y-4 text-base text-muted">
              <p>
                I am {profile.fullName}, based in {profile.place}, Tanzania. I am interested in the point where software and engineering meet: a website that makes information easier to use, a system that automates a task, or a component designed for real-world production.
              </p>
              <p>
                My technical interests include Python, C++, HTML, CSS, web development, robotics, automation, electronics, laser work, and CAD/CAM. I value learning across disciplines and bringing the right skills together to solve a clearly defined problem.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="practice" className="scroll-mt-20 border-b border-line">
        <div className="mx-auto w-full max-w-6xl px-5 py-20 md:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold tracking-widest text-accent uppercase">Practice</p>
            <h2 className="mt-3 font-display text-4xl font-bold text-fg sm:text-5xl">What I take on</h2>
            <p className="mt-4 text-muted">
              These are the areas I currently focus on. Select an area to see the kind of work involved. If your project needs a related skill that is not listed, feel free to ask about it.
            </p>
          </div>
          <div className="mt-10 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
            <div role="tablist" aria-label="Practice areas" className="flex flex-col" onKeyDown={onPracticeKey}>
              {practices.map((item) => {
                const selected = item.id === practice.id;
                return (
                  <button
                    key={item.id}
                    id={`practice-${item.id}`}
                    type="button"
                    role="tab"
                    aria-selected={selected}
                    aria-controls="practice-panel"
                    tabIndex={selected ? 0 : -1}
                    onClick={() => setPracticeId(item.id)}
                    className={cn(
                      "flex min-h-14 items-center justify-between gap-4 border-b border-line px-3 text-left transition-colors duration-200",
                      selected ? "bg-surface text-fg" : "text-muted hover:text-fg",
                    )}
                  >
                    <span className="flex items-baseline gap-4">
                      <span className={cn("font-display text-sm", selected ? "text-accent" : "text-muted")}>
                        {item.index}
                      </span>
                      <span className="text-lg font-semibold">{item.title}</span>
                    </span>
                    <span className="hidden text-sm sm:inline">{item.tools}</span>
                  </button>
                );
              })}
            </div>
            <div
              id="practice-panel"
              role="tabpanel"
              aria-labelledby={`practice-${practice.id}`}
              className="border border-line bg-surface p-6 sm:p-8"
            >
              <p className="font-display text-sm text-accent">{practice.index}</p>
              <h3 className="mt-3 font-display text-4xl font-bold text-fg">{practice.title}</h3>
              <p className="mt-2 text-sm font-medium text-fg">{practice.tools}</p>
              <p className="mt-5 text-lg text-fg">{practice.lead}</p>
              <p className="mt-3 text-muted">{practice.detail}</p>
              <ul className="mt-6 flex flex-wrap gap-2">
                {practice.includes.map((item) => (
                  <li key={item} className="border border-line bg-bg px-3 py-2 text-sm text-fg">
                    {item}
                  </li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => briefThis(practice.id)}
                className="mt-8 inline-flex h-12 items-center gap-2 bg-accent px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                Discuss a project
                <ArrowUpRight className="size-4" aria-hidden />
              </button>
            </div>
          </div>
        </div>
      </section>

      <section id="method" className="scroll-mt-20 border-b border-line bg-surface">
        <div className="mx-auto w-full max-w-6xl px-5 py-20 md:px-8">
          <p className="text-sm font-semibold tracking-widest text-accent uppercase">Method</p>
          <h2 className="mt-3 max-w-xl font-display text-4xl font-bold text-fg sm:text-5xl">A clear process, from brief to delivery</h2>
          <ol className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            {method.map((step) => (
              <li key={step.index} className="border-t border-line pt-5">
                <p className="font-display text-3xl font-bold text-accent">{step.index}</p>
                <h3 className="mt-4 text-xl font-semibold text-fg">{step.title}</h3>
                <p className="mt-2 text-sm text-muted">{step.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section id="contact" className="scroll-mt-20">
        <div className="mx-auto grid w-full max-w-6xl gap-12 px-5 py-20 md:px-8 lg:grid-cols-2">
          <div>
            <p className="text-sm font-semibold tracking-widest text-accent uppercase">Contact</p>
            <h2 className="mt-3 font-display text-4xl font-bold text-fg sm:text-5xl">Let’s discuss what you have in mind.</h2>
            <p className="mt-4 max-w-md text-muted">
              For project enquiries, WhatsApp is the quickest way to reach me. You can also contact me by email or through the professional links below.
            </p>
            <ul className="mt-8 divide-y divide-line border-y border-line">
              <Channel
                icon={<MessageCircle className="size-4" aria-hidden />}
                label="WhatsApp"
                value={profile.phoneDisplay}
                href={whatsappHref}
                action="Open"
              />
              <Channel
                icon={<Mail className="size-4" aria-hidden />}
                label="Personal"
                value={profile.email}
                href={`mailto:${profile.email}`}
                action="Email"
                onCopy={() => copy(profile.email, "personal")}
                copied={copied === "personal"}
              />
              <Channel
                icon={<Mail className="size-4" aria-hidden />}
                label="Sentra"
                value={profile.emailAlt}
                href={`mailto:${profile.emailAlt}`}
                action="Email"
                onCopy={() => copy(profile.emailAlt, "sentra")}
                copied={copied === "sentra"}
              />
              <Channel
                icon={<Linkedin className="size-4" aria-hidden />}
                label="LinkedIn"
                value="penuel-george-kayala"
                href={profile.linkedin}
                action="Open"
              />
              <Channel
                icon={<Instagram className="size-4" aria-hidden />}
                label="Instagram"
                value="@penuelgeorge.tz"
                href={profile.instagram}
                action="Open"
              />
            </ul>
            <p className="sr-only" aria-live="polite">
              {copied ? "Copied" : ""}
            </p>
          </div>

          <form
            className="border border-line bg-surface p-6 sm:p-8"
            onSubmit={(event) => event.preventDefault()}
          >
            <h3 className="font-display text-2xl font-bold text-fg">Start a brief</h3>
            <p className="mt-2 text-sm text-muted">Select a project area and add a few details. Your message will open in WhatsApp or your chosen email app; it is not stored on this page.</p>
            <fieldset className="mt-6">
              <legend className="text-sm font-medium text-fg">What is it?</legend>
              <div className="mt-3 flex flex-wrap gap-2">
                {topics.map((item) => {
                  const selected = item.id === topicId;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      aria-pressed={selected}
                      onClick={() => setTopicId(item.id)}
                      className={cn(
                        "h-11 px-3 text-sm font-medium transition-colors duration-200",
                        selected ? "bg-accent text-accent-fg" : "border border-line bg-bg text-fg hover:border-accent",
                      )}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </fieldset>
            <label className="mt-5 block text-sm font-medium text-fg" htmlFor="brief-name">
              Your name <span className="font-normal text-muted">(optional)</span>
            </label>
            <input
              id="brief-name"
              name="name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              autoComplete="name"
              className="mt-2 h-12 w-full border border-line bg-bg px-4 text-fg"
            />
            <label className="mt-5 block text-sm font-medium text-fg" htmlFor="brief-note">
              The job
            </label>
            <textarea
              id="brief-note"
              name="note"
              value={note}
              onChange={(event) => setNote(event.target.value)}
              rows={4}
              placeholder="What should exist when this is finished?"
              className="mt-2 min-h-32 w-full border border-line bg-bg px-4 py-3 text-fg placeholder:text-muted"
            />
            <fieldset className="mt-5">
              <legend className="text-sm font-medium text-fg">Email inbox</legend>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {(
                  [
                    ["personal", "Personal"],
                    ["sentra", "Sentra"],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    aria-pressed={inbox === id}
                    onClick={() => setInbox(id)}
                    className={cn(
                      "h-11 text-sm font-medium",
                      inbox === id ? "bg-fg text-bg" : "border border-line text-fg hover:border-accent",
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </fieldset>
            <div className="mt-5 border border-line bg-bg p-4">
              <p className="text-xs font-semibold tracking-widest text-muted uppercase">Message preview</p>
              <p className="mt-2 text-sm whitespace-pre-wrap text-fg">{draft}</p>
            </div>
            <div className="mt-5 flex flex-col gap-3">
              <a
                href={whatsappMessageHref(draft)}
                className="inline-flex h-12 items-center justify-center gap-2 bg-accent px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                <MessageCircle className="size-4" aria-hidden />
                Send on WhatsApp
              </a>
              <a
                href={mailtoHref(email, topic.label, draft)}
                className="inline-flex h-12 items-center justify-center gap-2 border border-line px-5 text-sm font-semibold text-fg hover:border-accent"
              >
                <Mail className="size-4" aria-hidden />
                Send by email
              </a>
            </div>
          </form>
        </div>
      </section>
    </main>
  );
}

function Social({ href, label, children }: { href: string; label: string; children: ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      aria-label={label}
      className="inline-flex h-11 items-center gap-2 border border-line bg-surface px-4 text-sm font-medium text-fg transition-colors duration-200 hover:border-accent"
    >
      {children}
      {label}
    </a>
  );
}

function Channel({
  icon,
  label,
  value,
  href,
  action,
  onCopy,
  copied,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  href: string;
  action: string;
  onCopy?: () => void;
  copied?: boolean;
}) {
  const external = href.startsWith("http");
  return (
    <li className="flex items-center gap-3 py-3">
      <span className="inline-flex size-10 shrink-0 items-center justify-center border border-line text-accent">
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-xs font-semibold tracking-widest text-muted uppercase">{label}</span>
        <span className="block text-sm break-all text-fg">{value}</span>
      </span>
      <span className="flex shrink-0 items-center gap-1">
        {onCopy ? (
          <button
            type="button"
            onClick={onCopy}
            className="inline-flex size-11 items-center justify-center text-muted hover:text-fg"
            aria-label={copied ? `${label} copied` : `Copy ${label}`}
          >
            {copied ? <Check className="size-4 text-accent" aria-hidden /> : <Copy className="size-4" aria-hidden />}
          </button>
        ) : null}
        <a
          href={href}
          target={external ? "_blank" : undefined}
          rel={external ? "noreferrer" : undefined}
          className="inline-flex h-11 items-center px-2 text-sm font-semibold text-fg hover:text-accent"
        >
          {action}
        </a>
      </span>
    </li>
  );
}
