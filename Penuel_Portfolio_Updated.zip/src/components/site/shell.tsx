import { useEffect, useState, type ReactNode } from "react";
import { Menu, X } from "lucide-react";
import { profile, whatsappHref } from "@/content/site";
import { cn } from "@/lib/cn";

const anchors = [
  { id: "about", label: "About" },
  { id: "practice", label: "Practice" },
  { id: "method", label: "Method" },
  { id: "contact", label: "Contact" },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [time, setTime] = useState("");

  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Africa/Dar_es_Salaam",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
    });
    const tick = () => setTime(fmt.format(new Date()));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const ids = anchors.map((item) => item.id);
    const nodes = ids
      .map((id) => document.getElementById(id))
      .filter((node): node is HTMLElement => Boolean(node));
    if (!nodes.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-40% 0px -45% 0px", threshold: [0.1, 0.25, 0.5] },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!open) return;
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className="min-h-screen bg-bg text-fg">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-fg"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-5 md:px-8">
          <a href="#top" className="font-display text-lg font-bold tracking-wide text-fg" aria-label="Penuel George, home">
            PENUEL
          </a>
          <nav className="hidden items-center gap-7 md:flex" aria-label="Primary">
            {anchors.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={cn(
                  "text-sm font-medium transition-colors duration-200",
                  active === item.id ? "text-accent" : "text-muted hover:text-fg",
                )}
                aria-current={active === item.id ? "true" : undefined}
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <p className="hidden items-center gap-2 text-sm text-muted lg:flex">
              <span>{profile.place}</span>
              <span className="text-muted" aria-hidden>
                /
              </span>
              <span className="tabular-nums text-fg">{time || "—"}</span>
              <span>EAT</span>
            </p>
            <a
              href={whatsappHref}
              className="inline-flex h-11 items-center bg-accent px-4 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              WhatsApp
            </a>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center text-fg md:hidden"
              aria-expanded={open}
              aria-controls="mobile-nav"
              onClick={() => setOpen((value) => !value)}
            >
              {open ? <X className="size-5" aria-hidden /> : <Menu className="size-5" aria-hidden />}
              <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
            </button>
          </div>
        </div>
        {open ? (
          <nav id="mobile-nav" className="border-t border-line bg-bg md:hidden" aria-label="Mobile">
            <div className="mx-auto flex w-full max-w-6xl flex-col px-5 py-2">
              {anchors.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  className="flex h-12 items-center border-b border-line text-base font-medium text-fg"
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </a>
              ))}
            </div>
          </nav>
        ) : null}
      </header>
      <div id="content">{children}</div>
      <footer className="border-t border-line">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-5 py-14 md:px-8">
          <p className="font-display text-5xl font-bold leading-none text-fg sm:text-7xl">
            Penuel
            <br />
            George
          </p>
          <div className="flex flex-col gap-4 text-sm text-muted sm:flex-row sm:items-end sm:justify-between">
            <p className="max-w-sm text-fg">{profile.slogan}</p>
            <p>
              {profile.place}, {profile.country}
              <span className="mx-2 text-line">·</span>
              {new Date().getFullYear()}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
